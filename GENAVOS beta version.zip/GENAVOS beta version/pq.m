function [p , q ]= pq ( phi ,c ,n , N )
co = zeros ( n +N ,1) ;
si = zeros ( n +N ,1) ;
p = zeros ( n +N ,1) ;
q = zeros ( n +N ,1) ;
for i = 1: N + n
co ( i ) = cos ( i * c ) ;
si ( i ) = sin ( i * c ) ;
end
p (1) = phi (1) * co (1) ;
q (1) = phi (1) * si (1) ;
for i = 2: N + n
p ( i ) = p (i -1) + phi ( i ) * co ( i ) ;
q ( i ) = q (i -1) + phi ( i ) * si ( i ) ;
end
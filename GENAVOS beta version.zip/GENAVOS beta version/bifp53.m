global fu
global par
global n
global st
global mbip
global bip;
global pp
global cc
global sameor;
global or1
global or2
global ortemp;
global BestSol1;
global TSim;
global h
global b
global To;
global t
global np;
sameor=1;
par=[];
fu=[];
h1 = waitbar(0,'please wait.....');
for a=0:st:mbip
if strcmp(bip.Text,'h')
h=a+0.001;
sameor=0;
n=round(TSim/h);
m=round(To/h);
a1=-m:n;
b=size(a1,2);
t=-m*h:h:TSim;
end
    
if strcmp(bip.Text,'P')
BestSol1.Position(1,pp)=a*20;
sameor=1;
end
if strcmp(bip.Text,'C')
BestSol1.Position(1,(np+cc))=a;
sameor=1;
end
if strcmp(bip.Text,'Delay')
To=a;
n=round(TSim/h);
m=round(To/h);
a1=-m:n;
b=size(a1,2);
t=-m*h:h:TSim;
sameor=0;
end
if strcmp(bip.Text,'Order Variation Parameter(K)')
sameor=1;
if isempty(or2)
   metadata;
end
or1=ortemp+a*(or2-ortemp);
% or1=(or1-(min(or1)))./((max(or1))-(min(or1)));
end
if strcmp(bip.Text,'E')
BestSol1.Position(1,end)=a*10;
sameor=1;
end
[e,T,Y,yh,ord]=MEPE53(BestSol1.Position);
rt(1,:)=a*ones(1,0.3*n);
par=[par rt(1,:)];
fu=[fu Y((n-0.3*n+1):end,:)'];
waitbar(a/mbip);  
end
close(h1);


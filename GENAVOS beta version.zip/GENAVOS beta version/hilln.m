function y=hilln(a,n,x)
y=(a.^n)./(a.^n+x.^n);
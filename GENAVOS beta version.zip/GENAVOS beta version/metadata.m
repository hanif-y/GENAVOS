global BestSol2
global or2;

CreateStruct.Interpreter = 'tex';
CreateStruct.WindowStyle = 'non-modal';
f = msgbox('\fontsize{20} Please enter comparative data',CreateStruct);
pause(1)
close(f);
[file1,path1] = uigetfile('*.mat','Select One File');  
ort=load([path1,file1]);
or2=ort.or1;
BestSol2=ort.BestSol;

CreateStruct.Interpreter = 'tex';
CreateStruct.WindowStyle = 'non-modal';
f = msgbox('\fontsize{20} Data was loaded successfully.',CreateStruct);
pause(2);
close(f);
function a=SEQGRN1(p,r,q1,q2,y,top,N)
a(1:size(top,1),1)=0;
k=0;
g=0;
for i=1:size(top,1)
for j=1:size(top,2)
    if top(i,j)==1
        k=k+1;
        kk=k-g;
       
      a(i,1)=a(i,1)+ p(k)*logsigp(r(kk),N,y(j,q1)); 
    end
    if top(i,j)==-1
        k=k+1;
        kk=k-g;
      a(i,1)=a(i,1)+ p(k)*logsign(r(kk),N,y(j,q1)); 
    end
    if j==size(top,2)
        k=k+1;
        g=g+1;
        
    a(i,1)=a(i,1)-p(k)*y(i,q2); 
    end
end
end
% for i=1:size(top,1)
%     k=k+1;
% a(i,1)=a(i,1)-p(k)*y(i,q2);
% end
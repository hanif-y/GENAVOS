global Df;
% global D1;
D=importdata('helap53shifted.csv');
% D1=D.data(:,90:106);
D1=D.data;
% D2=D.data(:,19:end);
t1=0:2:33;
% t=0:0.1:33;
% for i=1:size(D1,1)
% Df1(i,:) = interp1(t1,D1(i,:),t,'spline');
% end
Df=D1;
% Df=zscore(Df,[],2);
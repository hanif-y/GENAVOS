global Df;

% global D1;
D=importdata('normalcellp53.csv');
D1=D.data(:,1:17);
D2=D.data(:,19:end);
t1=0:2:33;
% t=0:h:33;
% for i=1:size(D1,1)
% Df1(i,:) = interp1(t1,D1(i,:),t,'spline');
% end
Df=D1([2 3 6 10],:);
% Df=zscore(Df,[],2);
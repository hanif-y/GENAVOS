global Df;
global G1;
D=importdata('helacellcycle.csv');
D1=D.data(:,90:106);
D2=D.data(:,19:end);
G=D.textdata(:,1);
% t1=0:2:33;
% t=0:0.1:33;
% for i=1:size(D1,1)
% Df1(i,:) = interp1(t1,D1(i,:),t,'spline');
% end
% Df=D1([3 5 6 7 8 10 11],:);
% G1=G([3 5 6 7 8 10 11],:);
Df=D1([2 5 6 7 8 10 11],:);
G1=G([2 4 6 7 9 10 11],:);
% Df=zscore(Df,[],2);
% vq3=vq3+(vq2(1)-vq3(1));
Df=Df+(Dnor-Df(:,1));
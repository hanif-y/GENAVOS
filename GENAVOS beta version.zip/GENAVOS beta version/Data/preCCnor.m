global Df;
global G1;
D=importdata('normal cell net full.csv');
D1=D.data(:,1:17);
D2=D.data(:,19:end);
G=D.textdata(:,1);
% t1=0:2:33;
% t=0:0.1:33;
% for i=1:size(D1,1)
% Df1(i,:) = interp1(t1,D1(i,:),t,'spline');
% end
Df=D1([1 2 4 6 8 9 12],:);
G1=G([1 2 4 6 8 9 12],:);
% Df=zscore(Df,[],2);
% vq3=vq3+(vq2(1)-vq3(1));

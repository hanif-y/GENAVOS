function y=hillp(a,n,x)
y=(x.^n)./(a.^n+x.^n);
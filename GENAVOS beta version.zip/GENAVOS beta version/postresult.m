global pl;
a=find(pl==0);
global sampletime
global or1;
global BestSol
global gnum;
global TSim
global h;
global sameor;
global inse;
global Y0;
global Df;
global t;
global To;
global G1;
refp=size(a,2);
Y0=inse.*Df(:,1);
sameor=0;
n=round(TSim/h);
m=round(To/h);
a1=-m:n;
b=size(a1,2);
t=-m*h:h:TSim;

[e,T,Y,yh,or1]=MEPE53(BestSol.Position);

figure
for i=1:size(a,2)
subplot(ceil(refp/2),2,i)
plot(0:sampletime:TSim,yh(a(1,i),:)','o',0:sampletime:TSim,Y(1:sampletime/h:end,a(1,i)),'LineWidth',1.5);
% xlabel('Time(Hour)');
ylabel('Expr');
title(sprintf('State Variable %s',char(G1(a(1,i),1))));
grid on;
ax = gca;
ax.FontSize = 12;
ax.LineWidth=1.5;
end
figure

for i=1:size(a,2)
subplot(ceil(refp/2),2,i)
plot(0:sampletime:TSim,yh(a(1,i),:)','o',0:h:(TSim-h),Y(1:end,a(1,i)),0:sampletime:TSim,yh(a(1,i),:)','.','LineWidth',1.5);
% xlabel('Time(Hour)');
ylabel('Expr');
title(sprintf('State Variable %s',char(G1(a(1,i),1))));    
grid on;
ax = gca;
ax.FontSize = 12;
ax.LineWidth=1.5;
end
sh=[0.238266363745563,-0.004112520413613,0.554904818294862,0.071428569583666];
lgd=legend(sprintf('Sampling Time=%d',sampletime),sprintf('Sampling Time=%s',num2str(h)),sprintf('Sum of Absolute Error=%s',num2str(e)));
lgd.NumColumns = 3;
lgd.Position=sh;
lgd.Box='off';
lgd.FontSize=15;
k=0;
figure
for i=1:(size(a,2)-1)
 for j=(i+1):size(a,2)
   k=k+1;  
    subplot(ceil(refp*(refp-1)/(6)),3,k)
    plot(Y(1:end,a(1,i)),Y(1:end,a(1,j)),'-','LineWidth',1.5);
    xlabel(sprintf('%s',char(G1(a(1,i),1))));
    ylabel(sprintf('%s',char(G1(a(1,j),1))));
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
 end
end
% sh=ax.OuterPosition-[0.25,0.06,0.0,0.25];
lgd=legend('Phase Plane');
lgd.NumColumns = 1;
lgd.Position=[0.434459623254944,0.956448390739309,0.115666176289276,0.046012268750214];
lgd.Box='off';
lgd.FontSize=15;
figure
for i=1:size(a,2)
 
    subplot(ceil(refp/2),2,i)
    plot(t,or1(a(1,i),:)','LineWidth',1.5);
%     xlabel('Time(Hour)');
    title(sprintf('Order function of %s',char(G1(a(1,i),1))));    
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
end

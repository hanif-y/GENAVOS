global pl;
a=find(pl==0);
refp=size(a,2);
global bip;
% global gnum;
global TSim
global h;
% global sampletime
global BestSol2;
global KYD
global H
global Lambda
global or1
global or2;
global lexp
global chtest
global BestSol1;
global To;
global kmedian
global n

global G1;
global too
% 
% if isempty(BestSol2)
%     metadata;
% end
% if strcmp(bip.Text,'h')
% h=newvalp;
% sameor=0;
% end
% if strcmp(bip.Text,'P')
% BestSol1.Position(1,pp)=newvalp*20;
% sameor=1;
% end
% if strcmp(bip.Text,'C')
% BestSol1.Position(1,(np+cc))=newvalp;
% sameor=1;
% end
% if strcmp(bip.Text,'Delay')
% To=newvalp;
% n=round(TSim/h);
% m=round(To/h);
% a1=-m:n;
% b=size(a1,2);
% t=-m*h:h:TSim;
% sameor=0;
% end
% if strcmp(bip.Text,'Order Variation Parameter(K)')
% sameor=1;    
% or1=ortemp+newvalp*(or2-ortemp);
% end
% if strcmp(bip.Text,'E')
% BestSol1.Position(1,end)=newvalp*10;
% sameor=1;
% end
totemp2=To;
[e,T,Y,yh,ord]=MEPE53(BestSol1.Position);
ortemp1=or1;
or1=or2;
To=too;
[e1,T1,Y1,yh1,ord1]=MEPE53(BestSol2.Position);
or1=ortemp1;
To=totemp2;
figure
for i=1:size(a,2)
 
    subplot(ceil(refp/2),2,i)
    plot(0:h:(TSim-h),Y(1:end,a(1,i)),0:h:(TSim-h),Y1(1:end,a(1,i)),'LineWidth',1.5);
    title(sprintf('State Variable %s',char(G1(a(1,i),1))));
    ylabel('Expr');
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
end
if strcmp(bip.Text,'Order Variation Parameter(K)')
sh=[[0.137140088790564,0.00156501514379353,0.759150784806312,0.0460122687502142]];
lgd=legend('Predicted GRN response','The actual GRN response');
lgd.NumColumns = 2;
lgd.Position=sh;
lgd.Box='off';
lgd.FontSize=15;
end
k=0;


figure
for i=1:(size(a,2)-1)
 for j=(i+1):size(a,2)
   k=k+1;  
    subplot(ceil(refp*(refp-1)/(6)),3,k)
    plot(Y(1:end,a(1,i)),Y(1:end,a(1,j)),'-','LineWidth',1.5);

    xlabel(sprintf('%s',char(G1(a(1,i),1))));
    ylabel(sprintf('%s',char(G1(a(1,j),1))));
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
 end
end
lgd=legend('Phase Plane');
lgd.NumColumns = 1;
lgd.Position=[0.434459623254944,0.956448390739309,0.115666176289276,0.046012268750214];
lgd.Box='off';
lgd.FontSize=15;
kmedian=[];

if lexp==1
H=[];
pValue=[];
Lambda=[];
h1 = waitbar(0,'please wait.....');
[~,~,~, Orders,~,~] = chaostest(Y(:,1)','LOGISTIC');    
    for j=1:size(Y,2)
[H(j), ~, Lambda(j),~,~, allLambda] = chaostest(Y(:,j)', 'LOGISTIC',Orders); 
uu=reshape(allLambda,1,[]);
uu=sort(uu,'descend');
for i=1:size(uu,2)
    ar=sum(uu(1,1:i));
    if ar<0
        br=sum(uu(1,1:i-1));
        KYD(j)=(i-1)+(br/abs(uu(1,i)));
        break
    end
end
waitbar(j/size(Y,2));
    end
    close(h1);
end
if chtest==1
    pg=[];
    qg=[];
    p={};
    q={};
    p1=[];
    q1=[];
    pp=[];
    qq=[];
    kmedi=[];
    kmedian1=[];
    h1 = waitbar(0,'please wait.....');
    for k=1:500
%         c=unifrnd(pi/5,2*pi/5);
cc=[pi/20 pi/10 pi/5 pi/5 pi/5 pi/5 pi/10 pi/5 2*pi/5 3*pi/5 4*pi/5];
c=cc(randi([1 11],1));
% cc=[pi/10 pi/10 pi/5 pi/5 2*pi/5 3*pi/5 4*pi/5];
% c=cc(randi([1 7],1));
    for j=1:size(Y,2)
%     kmedian1(:,j)=z1test(Y(:,j)');
% x=0.1:0.1:33;
% v=Y(:,j);
% xq=0.1:0.01:33;
%      vq2 = interp1(x,v,xq,'spline');
if max(Y(:,j))>100
Y(:,j)=zscore(Y(:,j))+3;
%     Y(:,j)=((Y(:,j)-min(Y(:,j)))./(max(Y(:,j))-min(Y(:,j)))).*(10)-1;
end

% Y(:,j)=((Y(:,j)-min(Y(:,j)))./(max(Y(:,j))-min(Y(:,j)))).*(100)-1;
    [pg(:,j) , qg(:,j) ]= pq ((Y(1:1:end,j)),c ,5 ,n-5);
    
    end
    kmedi(k,:)=searchK (pg,qg,5 ,n-5);
    p{k}=pg;
    q{k}=qg;

    waitbar(k/100);
    end
   figure;
    for jj=1:size(Y,2)
        pp=[];
        qq=[];
        for kk=1:100
        pp(:,kk)=p{1,kk}(:,jj);
        qq(:,kk)=q{1,kk}(:,jj);
        end
        pp=pp';
        qq=qq';
        p1(:,jj)=mean(pp);
        q1(:,jj)=mean(qq);
    end
    kmedian=mean(kmedi);
 
    close(h1);
    for i=1:size(a,2)
 
    subplot(ceil(refp/2),2,i)
    plot(p1(:,i),q1(:,i),'-','LineWidth',1.5);
    title(sprintf('0-1 Test'));
    ylabel('q');
    xlabel('p');
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
    end
end
    
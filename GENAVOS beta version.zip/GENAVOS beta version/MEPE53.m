function [e,T,Y,yh,ord]=MEPE53(x)
global Df;
global b;
global TSim;
global h;
global To
global sameor
global samepar
global fselect
global t
global type
global or1
global BestSol
global top
global gnum;
global c1 c2 c3;
global A1;
global sampletime
global yal;
global np;
global Y0;
global extra;
for j=1:size(x,1)

if samepar==1
p=BestSol.Position(1,1:np)./20;
r=(BestSol.Position(1,(np+1):(np+yal)));
else
% p=mkfd(x(j,1:10),5,0);
p=x(j,1:np)./20;
r=(x(j,(np+1):(np+yal)));

end

if sameor==1
ord=or1;
else
    switch fselect
        case 1
for i=1:gnum
    ord(i,:)=mkfd(x(j,[(np+yal+1):((np+yal+1)+b-1)]+(i-1)*((np+yal+1)+b)),1,0.1);
end
        case 2
for i=1:gnum
    ord(i,:)=mkfrbf1(h,TSim,To,x(j,[(np+yal+1):(np+yal+50)]+(i-1)*100),x(j,[(np+yal+51):(np+yal+100)]+(i-1)*100));
end
        case 3
for i=1:gnum
ord(i,:)=mkorcos(h,TSim,To,x(j,[(np+yal+1):(np+yal+40)]+(i-1)*40));
end 
        case 4
ord=(c1+c2.*cos(t./c3)).*ones([gnum,b]); 
        case 5
ord=A1.*ones([gnum,b]); 
        case 6
cc1=(x(j,(np+yal+1):(np+yal+gnum))'./200);
cc2=(x(j,(np+yal+gnum+1):(np+yal+2*gnum))'./200);
cc3=(x(j,(np+yal+2*gnum+1):(np+yal+3*gnum))');
ord=(cc1+cc2.*cos(t.*cc3)).*ones([gnum,b]);
    end
end

if extra==1 && fselect==2
y1=(x(j,(np+yal+201)+(gnum-1)*100)/10)*mkfrbf1(h,TSim,0,x(j,[(np+yal+101):(np+yal+150)]+(gnum-1)*100),x(j,[(np+yal+151):(np+yal+200)]+(gnum-1)*100));
Y00=[Y0;y1(1,1)];
elseif extra==1 && fselect==5
y1=(x(j,(np+yal+101))/10)*mkfrbf1(h,TSim,0,x(j,(np+yal+1):(np+yal+50)),x(j,(np+yal+51):(np+yal+100)));
Y00=[Y0;y1(1,1)];    
else
Y00=Y0;
end

switch type
    case 1
N=1;         
% [T, Y]=MEQGRNL53(p,r, ord,h, TSim, Y0,To,N);
[T, Y]=MEQGRNL(p,r,ord,h,TSim,Y00,To,N,top);
    case 2
N=1.5;         
% [T, Y]=MEQGRNH53(p,r, ord,h, TSim, Y0,To,N);
[T, Y]=MEQGRNH(p,r,ord,h,TSim,Y00,To,N,top);

end 
if extra==1 && fselect==2
yh=[Df;y1(1,1:sampletime/h:end)];
yp=Y';
elseif extra==1 && fselect==5
yh=[Df;y1(1,1:sampletime/h:end)];
yp=Y';
else
yh=Df;
yp=Y';
end

e(j,1)=sum(sum(abs(yp(:,1:sampletime/h:end)-yh),2));

end

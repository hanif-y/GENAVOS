function [T, Y]=MEQGRNH(p,r, or,h, TSim, Y0,To,N,top)

% number of calculated mesh points:
n=round(TSim/h);

To=abs(To);

m=round(To/h);
if m~=0

a=-m:n;
else
    m=1;
a=1:n;
end
b=1:size(a,2);
%orders of derivatives, respectively:
%q1=or(1,:); q2=or(2,:); q3=or(3,:);q4=or(4,:);
q=or;

% binomial coefficients calculation:
% cp1=1; cp2=1; cp3=1;cp4=1;
cp=ones([1 size(top,1)]);
for k=1:size(top,1)
for j=b
    c(k,j)=(1-(1+q(k,j))/j)*cp(k);


    cp(k)=c(k,j); 
% cp2=c2(j); cp3=c3(j);cp4=c4(j);

end
end
% initial conditions setting:
% y1(1)=Y0(1); y2(1)=Y0(2); y3(1)=Y0(3);y4(1)=Y0(4);
y=Y0;

for i=2:n
    if i<=(m)



    y(:,i)=SEQGRN(p,r,1,i-1,y,top,N).*h.^q(:,i) - memo1(y, c, (i));
    end
    if i>(m)

    
    y(:,i)=SEQGRN(p,r,i-m,i-1,y,top,N).*h.^q(:,i) - memo1(y, c, (i));

    end
end

Y=y';
T=h:h:TSim;

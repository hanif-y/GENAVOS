function f=mkorcos(h,TSim,To,x)
 
n=round(TSim/h);
m=round(To/h);
a=-m:n;
% t=0:TSim/(n-1):TSim;
t=-m*h:h:TSim;
f=0;
for i=2:(size(x,2)-2)
% f=f+x(:,i)*cos(t.*x(:,i+1))+x(:,i+2)*sin(t.*x(:,i+1));
f=f+x(:,i)*cos(t.*x(:,i+1)+x(:,i+2));
end
f=f+x(:,1);
f=(f-min(f))./(max(f)-min(f));
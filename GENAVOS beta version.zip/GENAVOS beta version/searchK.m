function K = searchK (p,q ,nn ,N)
s = 0;
M=[];
K=[];

for j=1:nn
    s=0;
for i = 1: N
s = s + (( p ( i + j ,:) -p ( i,: ) ) .^2 + ( q ( i + j,: ) -q (i,: ) ) .^2) ;
end
% Ef=mean(phi).^2;
% vos=Ef.*((1-cos(nn*c))./(1-cos(c)));
M(j,:)=s./N;
end
% Dc=M-vos;
% Dc=Dc+min(abs(Dc))*1.1;

% K = log10( M ) ./ log10( nn ) ;
for kk=1:size(M,2)
    r=corrcoef(M(:,kk),(1:nn)');
K(1,kk)=r(1,2);
end


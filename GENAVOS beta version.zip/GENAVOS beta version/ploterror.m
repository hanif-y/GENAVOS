global BestCost
global MeanCost
figure;
semilogy(BestCost,'b','LineWidth',2);
hold on;
semilogy(MeanCost,'r:','LineWidth',2);
grid on;
legend('Best Cost','Mean Cost');
xlabel('Decade');
ylabel('Sum of Absolute Error');
ax = gca;
ax.FontSize = 15;
ax.LineWidth=1.5;
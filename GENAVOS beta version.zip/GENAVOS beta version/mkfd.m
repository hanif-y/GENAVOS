function y=mkfd(x,nmax,nmin)
y=(x-min(x))./(max(x)-min(x)).*(nmax-nmin)+nmin;
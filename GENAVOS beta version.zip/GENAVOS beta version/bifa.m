global fu
global par
global pl;
global bip
global G1;
a=find(pl==0);
refp=size(a,2);
% global gnum
figure
for i=1:size(a,2)
 
subplot(ceil(refp/2),2,i)
plot(par,fu(a(1,i),:),'.')
xlabel(bip.Text);
ylabel(sprintf('%s',char(G1(a(1,i),1))));
grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Portion of MATLAB Code for                                   %
%                                                               %
%  Imperialistic Competitive Algorithm (ICA)                    %
%  Version 1.9 - May 2010                                       %
%                                                               %
%  Programmed By: S. Mostapha Kalami Heris                      %
%                                                               %
%                                                               %
%         Site URL: http://www.matlabsite.com                   %
%                                                               %
%  Support e-Mails: info@matlabsite.com                         %
%                                                               %
%   Author e-Mails: sm.kalami@gmail.com                         %
%                   kalami@ee.kntu.ac.ir                        %
%                                                               %
%  Author Homepage: http://www.kalami.ir                        %
%                                                               %
%  This program has been modified by Hanif Yaghoobi in order to %
%  estimate the system parameters in GENAVOS Software           %
%  (Gene Network Analysis by Variable Order Systems)            %                        
%  -August 2020                                                 %
%  GENAVOS Correspondence email address:                        %
%  hanif_yaghoubi@tabrizu.ac.ir                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clc;
% clear all;
% close all;
global BestCost
global BestSol
global BestSol1
global MeanCost
global h
global hoo
global too
global ortemp
global or1;
global b;
global gnum
global TSim;
global ftype
global orsel
global type
global To
global n
global t
global top
global yal
global np
global fselect
global Df;
global Y0;
global extra;
global sameor
sameor=0;
Y0=Df(:,1);
if strcmp(ftype,'Hill Type')
    type=2;
elseif strcmp(ftype,'Logsigmoid')
    type=1;
end
if strcmp(orsel,'RBF Model')
    fselect=2;
elseif strcmp(orsel,'Constant')
    fselect=5;
elseif strcmp(orsel,'Fourier Series')
    fselect=3; 
elseif strcmp(orsel,'Cosine1')
    fselect=4;
elseif strcmp(orsel,'Cosine2') 
    fselect=6;
elseif strcmp(orsel,'Random Order')
    fselect=1;
end

yal=sum(sum(top~=0));
np=yal+gnum;

n=round(TSim/h);
m=round(To/h);
a=-m:n;
b=size(a,2);
t=-m*h:h:TSim;
hoo=h;
too=To;
%% Problem Definition

CostFunction=@(x) MEPE53(x);
% Number of Unknown Variables
switch fselect
    case 1
nVar=np+yal+b+(gnum-1)*(np+yal+1+b); 
    case 2
        if extra==1
nVar=np+yal+201+(gnum-1)*100;            
        else
nVar=np+yal+100+(gnum-1)*100;
        end
    case 3
nVar=np+yal+40+(gnum-1)*40;
    case 4
nVar=np+yal;
    case 5
        if extra==1
nVar=(np+yal+101);
        else
nVar=np+yal; 
        end
    case 6
nVar=np+yal+3*gnum; 
end
VarMin=0;    % Lower Bound of Unknown Variables
VarMax= 100;    % Upper Bound of Unknown Variables

%% ICA Settings
global nPop % Number of Countries
global nImp % Number of Imperials
nCol=nPop-nImp;
global MaxDecades

beta=2;
pRevolution=0.3;
zeta=0.1;

%% Initialization

ShareSettings;

imp=InitializeImperials();

BestSol.Position=[];
BestSol.Cost=[];

BestCost=zeros(ICASettings.MaxDecades,1);
MeanCost=zeros(ICASettings.MaxDecades,1);
% CreateStruct.Interpreter = 'tex';
% CreateStruct.WindowStyle = 'non-modal';
% f = msgbox('\fontsize{20} Parameters was changed successfully.',CreateStruct);
h1 = waitbar(0,sprintf('Please wait.....     Cost=%d',BestCost(1)));
set(findall(h1),'Units', 'normalized');
set(h1,'Position', [0.25 0.4 0.5 0.15]);
wax = findobj(h1, 'type','axes');
tax = get(wax,'title');
set(tax,'fontsize',15)
%% ICA
for Decade=1:MaxDecades
    global stop1
    imp=AssimilateColonies(imp);
    
    imp=RevolveColonies(imp);
    
    imp=ExchangeWithBestColony(imp);
    
    imp=CalculateTotalCosts(imp);
    
    imp=ImperialisticCompetition(imp);

    ImpCost=[imp.Cost];
    [BestImpCost BestImpIndex]=min(ImpCost);
    BestImp=imp(BestImpIndex);
    
    BestSol.Position=BestImp.Position;
    BestSol.Cost=BestImp.Cost;
    
    BestCost(Decade)=BestImpCost;
    MeanCost(Decade)=mean(ImpCost);
    
%     disp(['Decade ' num2str(Decade) ...
%           ': Best Cost = ' num2str(BestCost(Decade)) ...
%           ', Mean Cost = ' num2str(MeanCost(Decade)) ...
%           ', nImp = ' num2str(numel(imp))]);
 waitbar(Decade/MaxDecades,h1,sprintf('please wait.....Cost=%d',BestCost(Decade))); 
 if stop1==1
     break
 end
end
close(h1);
figure;
semilogy(BestCost,'b','LineWidth',2);
hold on;
semilogy(MeanCost,'r:','LineWidth',2);
legend('Best Cost','Mean Cost');
xlabel('Decade');
ylabel('Sum of Absolute Error');
ax = gca;
ax.FontSize = 15;
ax.LineWidth=1.5;
stop1=0;
[e,T,Y,yh,or1]=MEPE53(BestSol.Position);
ortemp=or1;
BestSol1=BestSol;
function y=logsign(a,b,x)
y=1./(1+exp(((b.*x)-a)));
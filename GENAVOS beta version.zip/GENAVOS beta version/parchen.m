global pl;
a=find(pl==0);
refp=size(a,2);
global bip;
% global gnum;
global TSim
global h;
% global sampletime
global BestSol2;
global pp
global cc
global sameor;
global or1
global or2;
global ortemp;
global newvalp;
global BestSol1;
global To;
global np;
global b;
global t;
global n;
if isempty(BestSol2)
    metadata;
end
if strcmp(bip.Text,'h')
h=newvalp;
sameor=0;
n=round(TSim/h);
m=round(To/h);
a1=-m:n;
b=size(a1,2);
t=-m*h:h:TSim;
end
if strcmp(bip.Text,'P')
BestSol1.Position(1,pp)=newvalp*20;
sameor=1;
end
if strcmp(bip.Text,'C')
BestSol1.Position(1,(np+cc))=newvalp;
sameor=1;
end
if strcmp(bip.Text,'Delay')
To=newvalp;
n=round(TSim/h);
m=round(To/h);
a1=-m:n;
b=size(a1,2);
t=-m*h:h:TSim;
sameor=0;
end
if strcmp(bip.Text,'Order Variation Parameter(K)')
sameor=1;    
or1=ortemp+newvalp*(or2-ortemp);
% or1=(or1-(min(or1)))./((max(or1))-(min(or1)));
end
if strcmp(bip.Text,'E')
BestSol1.Position(1,end)=newvalp*10;
sameor=1;
end
[e,T,Y,yh,or1]=MEPE53(BestSol1.Position);
CreateStruct.Interpreter = 'tex';
CreateStruct.WindowStyle = 'non-modal';
f = msgbox('\fontsize{20} Parameters was changed successfully.',CreateStruct);
pause(2);
close(f);